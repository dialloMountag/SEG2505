package com.example.projetseg2505;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.ext.junit.rules.ActivityScenarioRule;

import org.junit.Rule;
import org.junit.Test;

public class RegisterTest {

    /*
        @Rule
        public ActivityScenarioRule<Register> mActivityTestRule = new
                ActivityScenarioRule <>(Register.class);
        @Test
        public void emailIsInvalid() {
            onView(withId(R.id.password)).perform(typeText("thisIsMyPassword1"), closeSoftKeyboard());
            onView(withId(R.id.email)).perform(typeText("email@"), closeSoftKeyboard());
            onView(withId(R.id.rbEmployee)).perform(click());
            onView(withId(R.id.btnRegister)).perform(click());
            onView(withText("Invalid Email")).check(matches(isDisplayed()));
        }

        @Test
        public void passwordIsInvalid() {
            onView(withId(R.id.email)).perform(typeText("email@"), closeSoftKeyboard());
            onView(withId(R.id.password)).perform(typeText("1"), closeSoftKeyboard());
            onView(withId(R.id.rbEmployee)).perform(click());
            onView(withId(R.id.btnRegister)).perform(click());
            onView(withText("Invalid Password")).check(matches(isDisplayed()));
        }

     */

}
